
requirements 

laravel 5.7
php 7.0.8
composer 2.2
 

create the database same as in .env file

 to create the vendor folder run the following command on cmd on the root directory of the project

make sure Your lock file contain a compatible set of packages with running "composer update" command

after that you can make sure all the packages are installed with "composer install" command

you can find more packages with "composer fund" command

to migrate the database  run 


open the cmd , to run "php artisan serve" on the root directory of the project

navigate to localhost/laravel-master/public/ to visit the front end
navigate to localhost/laravel-master/public/admin to visit the back end(add products and categories)
admin password (username amogelangmakaba@gmail.com password 123456)