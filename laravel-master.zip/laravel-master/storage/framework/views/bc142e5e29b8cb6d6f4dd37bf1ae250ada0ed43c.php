<div class="col-md-4 well well-sm">
        

<nav class="nav flex-column">
 
  <a class="nav-link" href="<?php echo e('/profile'); ?>">My Profile</a>
  <a class="nav-link" href="<?php echo e('/orders'); ?>">My Orders</a>
  <a class="nav-link" href="<?php echo e('/address'); ?>">My Address</a>

   <a class="nav-link" href="<?php echo e(url('/password')); ?>">Change Password</a>
</nav>
</div>
