<?php $__env->startSection('content'); ?>



<br>
<br>
<br>
<br>

<br>
<br>
<br>
<br>

<main class="col-sm-9 ml-sm-auto col-md-10 pt-3" role="main">


<div class="row">
  <br>
<br>
<br>
<br>
    <div class="col-md-6">
        <br>
<br>
<br>
<br>

<br>
<br>
<br>
<br>
<h3>Categories</h3>

<table class="table table-dark">
            <thead>
                <tr>
                    
                    <th>Category Name</th>
                    <th>Edit</th>
                    <th>Status</th>
                    <th>Delete</th>
                </tr>
            </thead>

            <tbody>
        
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td><a href="<?php echo e(route('category.show',$category->id)); ?>">
                 <?php echo e($category->name); ?></a></td>
                 
            

                    <?php echo e($category->name); ?></a></td>

                     <td><?php if($category->status=='0'): ?>
                                    Enable
                                    <?php else: ?>
                                    Disable

                                    <?php endif; ?></td>
              

            <?php echo Form::open(['method'=>'DELETE', 'action'=> ['CategoriesController@destroy', $category->id]]); ?>



                <td>  <?php echo Form::submit('Delete Category', ['class'=>'btn btn-danger col-sm-6']); ?></td> 



                <?php echo Form::close(); ?>

                
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            </tbody>
    </table>
       

</div>
  

      <div class="col-md-4">

        <br>
<br>
<br>
<br>

<br>
<br>
<br>
<br>
           <div class="card card-body bg-success text-white py-5">
       <h2>Create Category</h2>
       <p class="lead">Lorem Ipsum has been the industry's standard dummy text ever since the</p>
          <?php echo Form::open(['route' => 'category.store', 'method' => 'post']); ?>

            <div class="form-group">
        <?php echo e(Form::label('name', 'Name')); ?>

        <?php echo e(Form::text('name', null, array('class' => 'form-control'))); ?>

            </div>

            <td>Category Status</td>

         
   
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Add Category</button>

          <?php echo Form::close(); ?>


     </div>
        
                <?php echo Form::open(['route' => 'category.store', 'method' => 'post']); ?>

              
                    
                </div>
                <?php echo Form::close(); ?>

            </div><!-- /.modal-content -->
     
    </div>

</div>


    
    <?php if(isset($products)): ?>

    <h3>Products</h3>

    <table class="table table-hover">
        <thead>
            <tr>
                <th>Products</th>
            </tr>
        </thead>
        <tbody>
<?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr><td><?php echo e($product->name); ?></td></tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td>no data</td></tr>
        <?php endif; ?>

        </tbody>
    </table>
    </main>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>