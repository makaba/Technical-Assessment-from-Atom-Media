<?php $__env->startSection('content'); ?>

  <style>
    table td { padding:10px
    }</style>

<br>
<br>
<br>
<br>

<section id="cart_items">
   <div class="container">
    <div class="col=md-12">

        
                
                <div class="col-md-4 well well-sm">

                <nav class="nav flex-column">
                
                 

               
              </nav>

              </div>
            </ol>
        </div><!--/breadcrums-->
            
        </div><!--/breadcrums-->

     </div>

</section>


<section id="cart_items">
    <div class="container">
     <div class="row">
  
          <?php echo $__env->make('profile.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 

   
     <div class="col-md-8">
       <ol class="breadcrumb">
                <li></li>
                
                  <table border="0" align="center"> 

                  
                  <tr>
                  <td>      <a href="<?php echo e(url('/')); ?>/orders" class="btn btn-success">My Orders</a></td>
                  <td>      <a href="<?php echo e(url('/address')); ?>" class="btn btn-success">My Address</a></td>
                  <td>      <a href="<?php echo e(url('/password')); ?>" class="btn btn-success">Change Password</a></td>
                  </tr>
                  </table>
                 * 
                 
                <h3><span style='color:green'><?php echo e(ucwords(Auth::user()->name)); ?></span>, Welcome</h3>
            </ol>
     </div>
        


</div>
</div>
   
</section>
    

<?php echo $__env->make('front.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>