<?php $__env->startSection('content'); ?>


  <div class="container-fluid">
      <div class="row">
        <nav class="col-sm-3 col-md-2 d-none d-sm-block bg-light sidebar">
         <?php echo $__env->make('admin.includes.sidenav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </nav>

        <main class="col-sm-9 ml-sm-auto col-md-10 pt-3" role="main">
        
        <h1>Dashboard</h1>
         <div class="col-md-6">
            <h1>BMW</h1>
        <h1>Add New </h1>

        <div class="panel-body">
        

        <?php echo Form::open(['route' => 'product.store', 'method' => 'post', 'files' => true]); ?>


          <div class="form-group">
                <?php echo e(Form::label('Proname', 'Name')); ?>

                <?php echo e(Form::text('pro_name', null, array('class' => 'form-control','required'=>'','minlength'=>'5'))); ?>

            </div>


          
            <div class="form-group">
                <?php echo e(Form::label('Code', 'Code')); ?>

                <?php echo e(Form::text('pro_code', null, array('class' => 'form-control'))); ?>

            </div>

             <div class="form-group">
                <?php echo e(Form::label('stock', 'stock')); ?>

                <?php echo e(Form::text('stock', null, array('class' => 'form-control'))); ?>

              </div>

            <div class="form-group">
                <?php echo e(Form::label('price', 'Price')); ?>

                <?php echo e(Form::text('pro_price', null, array('class' => 'form-control'))); ?>

            </div>


             <div class="form-group">
                <?php echo e(Form::label('Description', 'Description')); ?>

                <?php echo e(Form::text('pro_info', null, array('class' => 'form-control'))); ?>

            </div>

            <div class="form-group">
                 <?php echo e(Form::label('category_id', 'Categories')); ?>

                 <?php echo e(Form::select('category_id', $categories, null, ['class' => 'form-control', 'placeholder'=>'SelectCategory'])); ?>

            </div>

           
            <div class="form-group">
                <?php echo e(Form::label('image', 'Image')); ?>

                <?php echo e(Form::file('image',array('class' => 'form-control'))); ?>

            </div>

             <div class="form-group">
                <?php echo e(Form::label('Sale Price', 'Sale Price')); ?>

                <?php echo e(Form::text('spl_price', null, array('class' => 'form-control'))); ?>

            </div>
             
            <?php echo e(Form::submit('Submit', array('class' => 'btn btn-primary'))); ?>

             
   {<?php echo Form::close(); ?>}
       </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>