<?php $__env->startSection('content'); ?>




<script>
$(document).ready(function(){
  $('#size').change(function(){
    var size = $('#size').val();
    var proDum = $('#proDum').val();


    $.ajax({
        type: 'get',
        dataType: 'html',
        url: '<?php echo url('/selectSize');?>',
        data: "size=" + size + "& proDum=" + proDum,
        success: function (response) {
            console.log(response);
           $('#price').html(response);
        }
    });

  });
});

</script>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br> 



<div class="container align-vertical hero">
<div class="row">
<div class="col-md-5 text-left">


</div>
</div><!--end of row-->
</div><!--end of container-->
</header>


 

  <section id="index-amazon">

 
    <div class="amazon">
<div class="container">

<div class="row">
<div class="col-md-12">
<div class="product">
<div class="row">
<div class="col-md-6 col-xs-12">


<?php $__currentLoopData = $Products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<div class="thumbnail">
             <img src="<?php echo e(url('images',$product->image)); ?>" class="card-img">
                                <br>



</div>



<!-- ALT IMAGE  -->

 <div id="similar-product" class="carousel slide" data-ride="carousel">
                                
                                  <!-- Wrapper for slides -->
                                    <div class="carousel-inner">
                                      <div class="d-flex justify-content-between align-items-center">
                                        <div class="item active">
                                          <a href=""><img src="<?php echo e(url('images',$product->image)); ?>" alt=""></a>
                                          
                                        </div>
                                        <div class="item">
                                          <a href=""><img src="<?php echo e(url('images',$product->image)); ?>" alt=""></a>
                                          
                                        </div>
                                        <div class="item">
                                          <a href=""><img src="<?php echo e(url('images',$product->image)); ?>" alt=""></a>
                                         
                                        </div>
                                        
                                    </div>

                                  <!-- Controls -->
                                  <a class="left item-control" href="#similar-product" data-slide="prev">
                                    <i class="fa fa-angle-left"></i>
                                  </a>
                                  <a class="right item-control" href="#similar-product" data-slide="next">
                                    <i class="fa fa-angle-right"></i>
                                  </a>
                                  </div>
                            </div>

    




</div>
<div class="col-md-5 col-md-offset-1">

<div class="product-details">

<h2 class="product-title">
 <h2><?php echo ucwords($product->pro_name);?></h2>
 <h5><?php echo e($product->pro_info); ?></h5>






 <form action="<?php echo e(url('/cart/addItem')); ?>/<?php echo $product->id; ?>">


 <?php if($product->spl_price ==0): ?>

 <span id="price">

  $<?php echo e($product->pro_price); ?>

  
  <input type="hidden" value="<?php echo $product->pro_price;?>" name="newPrice"/>


  <?php else: ?>


  <div class="d-flex justify-content-between align-items-center">

          <input type="hidden" value="<?php echo $product->spl_price;?>" name="newPrice"/>
            <p class="" style="text-decoration:line-through; color:#333">$<?php echo e($product->spl_price); ?></p>
             <img src="<?php echo e(URL::asset('dist/images/shop/sale.png')); ?>" alt="..."  style="width:60px">
             <p class="">$<?php echo e($product->pro_price); ?></p>

             
           </div>


  <?php endif; ?>

 </span>
 </h2>
 <p><b>Availability:</b><?php echo e($product->stock); ?> In Stock</p>

 <?php $sizes = DB::table('products_properties')->where('pro_id',$product->id)->get(); ?>

  <select name="size" id='size'>

   <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option><?php echo e($size->size); ?></option>

   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </select>


   <?php if($product->new_arrival==1): ?>
   <img src="<?php echo e(URL::asset('dist/images/product-details/new.jpg')); ?>" alt="...">
    <?php endif; ?>

  
 
<button class="btn btn-fefault cart" id="addToCart">
   <i class="fa fa-shopping-cart"></i>
   Add to cart
</button>


<input type="hidden" value="<?php echo $product->id; ?>" id="proDum"/>


</form>

<?php
 $wishData = DB::table('wishlist')->rightJoin('products','wishlist.pro_id', '=', 'products.id')->where('wishlist.pro_id', '=', $product->id)->get();
 $count = App\wishlist::where(['pro_id' => $product->id])->count();
  ?>

 <?php if($count=="0"){?>

   <?php echo Form::open(['route' => 'addToWishList', 'method' => 'post']); ?>

    <input type="hidden" value="<?php echo e($product->id); ?>" name="pro_id"/>
    <input type="submit" value="Add to Wishlist" class="btn btn-primary"/>



   <?php echo Form::close(); ?>

  <?php } else {?>
     <h3 style="color:green">Already Added to Wishlist <a href="<?php echo e(url('/WishList')); ?>">wishlist</a></h3>
<?php }?>
<p class="">
 


</div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
</div>
</div><!-- /.row -->

        </div>
        </div>
      </section>


      <div class="no-padding-top section">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <a href="#" class="load-more"><i class="fa fa-ellipsis-h"></i></a>
                            </div>
                        </div><!-- /.row -->
                    </div><!-- /.container -->
                </div>

                <!-- Recommends table -->


               <div class="recommended_items"><!--recommended_items-->
                        <h2 class="title text-center">recommended items</h2>

                <?php echo $__env->make('front.recommends', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                  </div><!--/recommended_items-->
                    
                </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>