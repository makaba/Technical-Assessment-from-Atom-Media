 <?php $__env->startSection('content'); ?>


 


 <main role="main">
<br>
<br>
<br>
      <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
          <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
          <li data-target="#myCarousel" data-slide-to="1"></li>
          <li data-target="#myCarousel" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img class="first-slide" src="<?php echo e(URL::asset('dist/img/create-section1.jpg')); ?>" alt="First slide">
            <div class="container">
              <div class="carousel-caption text-left">
                <h1>Example headline.</h1>
                <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
                <p><a class="btn btn-lg btn-primary" href="#" role="button">Sign up today</a></p>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <img class="second-slide" src="<?php echo e(URL::asset('dist/img/explore-section1.jpg')); ?>" alt="Second slide">
            <div class="container">
              <div class="carousel-caption">
                <h1>Another example headline.</h1>
                <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
                <p><a class="btn btn-lg btn-primary" href="#" role="button">Learn more</a></p>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <img class="third-slide" src="<?php echo e(URL::asset('dist/img/rollsroysemain.jpg')); ?>" alt="Third slide">
            <div class="container">
              <div class="carousel-caption text-right">
                <h1>One more for good measure.</h1>
                <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
                <p><a class="btn btn-lg btn-primary" href="#" role="button">Browse gallery</a></p>
              </div>
            </div>
          </div>
        </div>
        <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
      </div>

      <div class="album text-muted">

      <div class="container">
       
        <div class="row">
         <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
           
          <div class="card" style="width:30rem height: 20rem">
         
             <img src="<?php echo e(url('images',$product->image)); ?>" class="card-img">
            
          <div class="card-body">

              <p id="price">
               

              <h4 class="card-text iphone"><a href="<?php echo e(url('/product_details')); ?>/<?php echo e($product->id); ?>" style="width:30rem height: 20rem"><?php echo e($product->pro_name); ?></a></h4>

            
            <?php if($product->spl_price==0): ?>


             <div class="d-flex justify-content-between align-items-center">
              <p class="card-text">$<?php echo e($product->pro_price); ?></p>
               <p class="card-text"></p>
              </div>

              <?php else: ?>

              <div class="d-flex justify-content-between align-items-center">
            <p class="" style="text-decoration:line-through; color:#333">$<?php echo e($product->spl_price); ?></p>

            <img src="<?php echo e(URL::asset('dist/images/shop/sale.png')); ?>" alt="..."  style="width:60px">
             <p class="">$<?php echo e($product->pro_price); ?></p>

             
           </div>
            <?php endif; ?>

          </p>
         
           
            
            <button class="btn btn-primary btn-sm">
             <a href="<?php echo e(url('/cart/addItem')); ?>/<?php echo $product->id; ?>" class="">Add ToCart<i class="fa fa-shopping-cart"></i></a>
            </button>

         
         
          </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h3>No Shirts</h3>
            <?php endif; ?>
          </div>
         </div>
         
        </div>

      </div>

    </main>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('front.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>