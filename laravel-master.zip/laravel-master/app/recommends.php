<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class recommends extends Model
{
    //
}
